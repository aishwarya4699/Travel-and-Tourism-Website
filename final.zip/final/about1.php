<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body, html {
    height: 100%;
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
}

.hero-image {
  background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("img/top-banner.jpg");
  height: 50%;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}

.hero-text {
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
}

.hero-text button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 10px 25px;
  color: black;
  background-color: #ddd;
  text-align: center;
  cursor: pointer;
}

.hero-text button:hover {
  background-color: #555;
  color: white;
}
</style>

<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

.bg-img {
  /* The image used */
  background-image: url("img/top-banner.jpg");

  min-height: 280px;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  
  /* Needed to position the navbar */
  position: relative;
}

/* Position the navbar container inside the image */
.container {
  position: top;
  margin: 20px;
  width: 100%;
}

/* The navbar */
.topnav {
  overflow: hidden;
  background-color:transparent  ;
}

/* Navbar links */
.topnav a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px 14px;
  text-decoration: none;
  font-size: 15px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}
div.gallery {
    margin: 10px;
    border: transparent;
    float: left;
    width: 300px;
}

div.gallery:hover {
    border: 1px solid #777;
}

div.gallery img {
    width: 100%;
    height: auto;
}

div.desc {
    padding: 50px;
    text-align: center;
}

</style>
</head>
<body>




<div class="hero-image">
	<div class="bg-img">
		<div class="container">
		
		<div class="topnav">
			<a href="index1.php">Home</a>
			<a href="about1.php">About</a>
			<a href="hotels2.php">Hotels</a>
			<a href="package1.php">Packages</a>
			<a href="gallery.php">Elements</a>
			 <a href="flights.php">Flights</a>
			<a href="registration1.php">Register</a>
		</div>
		</div>
	</div>
  <div class="hero-text">
    <h1 style="font-size:50px">About Us</h1>
    <p>Home->About Us</p>
    
  </div>
</div>
<br><br><br>
<br>
<div>
<div>
<img src="img/about/info-img.jpg" width="30%" align="left"><br>
</img>
<h1 align="center" color="white">Who Are We?</h1>
<p display="inline-block"><font size="4" >Travelicious... a destination for all people who love to travel<br>
						        Here we provide information on what to do and where to stay and helps you choose your travel destinations.
								This is the perfect place to find deals and new destinations.</font></p><br><br>

<br><br><br><br><br><br>
</div>
</div>
<div>
<p align="center">
	<font size="8" ><b><br>Other Issues We Can Help You With</b></font>
	</p><br><br>
<div class="gallery">
  <a target="_blank" href="img_5terre.jpg">
    <img src="img/o1.jpg" alt="5Terre" width="600" height="400">
  </a>
  <div class="desc">
  <h3>Rent a Car</h3>
  <p>Book your own car for your travel at an affordable rate</p>
  </div>
</div>

<div class="gallery">
  <a target="_blank" href="img_forest.jpg">
    <img src="img/o2.jpg" alt="Forest" width="600" height="400">
  </a>
  <div class="desc">
  <h3>Bus Services</h3>
  <p>Ride on the most pocket-friendly and pollution-free vehicles</p>
  </div>
</div>

<div class="gallery">
  <a target="_blank" href="img_lights.jpg">
    <img src="img/o3.jpg" alt="Northern Lights" width="600" height="400">
  </a>
  <div class="desc">
  <h3>To Do List</h3>
  <p>The following article covers a plan of your travel</p></div>
</div>

<div class="gallery">
  <a target="_blank" href="img_mountains.jpg">
    <img src="img/o4.jpg" alt="Mountains" width="600" height="400">
  </a>
  <div class="desc">
  <h3>Food Features</h3>
  <p>Get the food across the world</p>
  </div>
</div>
</div>


</body>
</html>
