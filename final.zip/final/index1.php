<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

.bg-img {
  /* The image used */
  background-image: url("img/hero-bg.jpg");

  min-height: 690px;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  
  /* Needed to position the navbar */
  position: relative;
}

/* Position the navbar container inside the image */
.container {
  position:top;
  margin: 20px;
  width: 100%;
}

/* The navbar */
.topnav {
  overflow: hidden;
  background-color:transparent;
}

/* Navbar links */
.topnav a {
  float: left;
  color: #000;
  text-align: center;
  padding: 12px 14px;
  text-decoration: none;
  font-size: 15px;
}

.topnav a:hover {
  background-color:#EDEDED;
  color: grey;
}
.hero-text {
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: Brown;
}

.hero-text button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 20px 35px;
  color: brown;
  background-color: #ddd;
  text-align: center;
  cursor: pointer;
}
.button {
  padding: 15px 25px;
  font-size: 24px;
  text-align: center;
  cursor: pointer;
  outline: none;
  color: #fff;
  background-color: #4CAF50;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

.button:hover {background-color: #3e8e41}

.button:active {
  background-color: #3e8e41;
  box-shadow: 0 5px #666;
  transform: translateY(4px);
}

.hero-text button:hover {
  background-color:#555;
  color: Yellow;
</style>
</head>
<body>


<div class="bg-img">
  <div class="container">
    <div class="topnav">
	
      <a href="index1.php">Home</a>
      <a href="about1.php">About</a>
      <a href="hotels2.php">Hotels</a>
      <a href="package1.php">Packages</a>
	  <a href="gallery.php">Elements</a>
	  <a href="flights.php">Flights</a>
	  <a href="registration1.php">Register</a>
	  <img src="C:/xampp/htdocs/final/logo1.png" align="right"></img>
    </div>
  </div>
  <div class="hero-text">
    <h1 style="font-size:60px">Dream Destinations</h1>
    <h3>Away from Montonous Life</h3>
    <button class="button">Welcome</button>
  </div>
</div>

</body>
</html>
