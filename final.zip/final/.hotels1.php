<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body, html {
    height: 100%;
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
}

.hero-image {
  background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("about-img.jpg");
  height: 50%;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}

.hero-text {
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
}

.hero-text button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 10px 25px;
  color: black;
  background-color: #ddd;
  text-align: center;
  cursor: pointer;
}

.hero-text button:hover {
  background-color: #555;
  color: white;
}
</style>

<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

.bg-img {
  /* The image used */
  background-image: url("about-img.jpg");

  min-height: 380px;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  
  /* Needed to position the navbar */
  position: relative;
}

/* Position the navbar container inside the image */
.container {
  position: top;
  margin: 20px;
  width: 100%;
}

/* The navbar */
.topnav {
  overflow: hidden;
  background-color:transparent  ;
}

/* Navbar links */
.topnav a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px 14px;
  text-decoration: none;
  font-size: 15px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

* {
    box-sizing: border-box;
}

.column {
    float: left;
    width: 33.33%;
    padding: 5px;
}

/* Clearfix (clear floats) */
.row::after {
    content: "";
    clear: both;
    display: table;
}

</style>
</head>
<body>
<div class="hero-image">
	<div class="bg-img">
		<div class="container">
		<div class="topnav">
			<a href="index1.php">Home</a>
			<a href="about1.php">About</a>
			<a href="hotels1.php">Hotels</a>
			<a href="package1.php">Packages</a>
			<a href="gallery.php">Elements</a>
			<a href="registration1.php">Register</a>
		</div>
		</div>
	</div>
  <div class="hero-text">
    <h1 style="font-size:50px">Hotels</h1>
    <p>Home->Hotel</p>
  </div>
</div>
<br><br><br><br><br>
<div>
	<p align="center">
	<font size="6" ><b><br>Popular Destinations</b></font>
	</p><br><br>
	<div class="row" align="center">
  <div class="column">
    <img src="hotels1.jpg" alt="h1" style="width:80%">
  </div>
  <div class="column">
    <img src="hotels2.jpg" alt="h2" style="width:80%">
  </div>
  <div class="column">
    <img src="hotels3.jpg" alt="h3" style="width:80%">
  </div>
  <br><br>
</div>
<div class="row" align="center">
  <div class="column">
    <img src="hotels4.jpg" alt="h1" style="width:80%">
  </div>
  <div class="column">
    <img src="hotels5.jpg" alt="h2" style="width:80%">
  </div>
  <div class="column">
    <img src="hotels6.jpg" alt="h3" style="width:80%">
  </div>
  <br><br>
</div>

<div class="row" align="center">
  <div class="column">
    <img src="hotels7.jpg" alt="h1" style="width:80%">
  </div>
  <div class="column">
    <img src="hotels8.jpg" alt="h2" style="width:80%">
  </div>
  <div class="column">
    <img src="hotels9.jpg" alt="h3" style="width:80%">
  </div>
  <br><br>
</div>
</body>
</head>
</html>