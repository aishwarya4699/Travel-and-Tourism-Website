<!DOCTYPE HTML> 
<html>
<head>
<link rel="stylesheet" type="text/css" href="style2.css">
<title>Sign-Up</title> 
</head> <body id="bg-img"> 
<div id="Sign-Up"> 
<fieldset style="width:30%">
<legend>Registration Form</legend> 
<table border="0">
<tr> 
<form method="POST" action="connectivity-sign-up.php"> 
<td>Name</td><td> <input type="text" name="name"></td> 
</tr> <tr> <td>Email</td><td> <input type="text" name="email">
</td> </tr> <tr> 
<td>UserName</td><td> 
<input type="text" name="user"></td> 
</tr> <tr> <td>Password</td><td> 
<input type="password" name="pass"></td> </tr> 
<tr> 
<td>Confirm Password </td><td><input type="password" name="cpass"></td> </tr> 
<tr> <td><input id="button" type="submit" name="submit" value="Sign-Up"></td> </tr> 
</form> </table> </fieldset> </div> 
<?php 
define('DB_HOST', 'localhost'); 
define('DB_NAME', 'practice'); 
define('DB_USER','root'); 
define('DB_PASSWORD',''); 
$con=mysql_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysql_error()); 
$db=mysql_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysql_error()); 
function NewUser() 
{ 
$fullname = $_POST['name']; 
$userName = $_POST['user']; 
$email = $_POST['email']; 
$password = $_POST['pass']; 
$query = "INSERT INTO websiteusers (fullname,userName,email,pass) VALUES ('$fullname','$userName','$email','$password')"; 
$data = mysql_query ($query)or die(mysql_error()); 
if($data) { echo "YOUR REGISTRATION IS COMPLETED..."; 
} 
} 
function SignUp() 
{ 
if(!empty($_POST['user'])) 
{ 
$query = mysql_query("SELECT * FROM websiteusers WHERE userName = '$_POST[user]' AND pass = '$_POST[pass]'") or die(mysql_error()); 
if(!$row = mysql_fetch_array($query) or die(mysql_error())) 
{ 
newuser(); 
} 
else 
{ 
echo "SORRY...YOU ARE ALREADY REGISTERED USER..."; 
} 
} 
} 
if(isset($_POST['submit'])) 
{ 
SignUp(); 
} 
?>


</body>
</html>

