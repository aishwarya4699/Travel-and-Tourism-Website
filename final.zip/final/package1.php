<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>

body, html {
    height: 100%;
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
}

.hero-image {
  background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("gallary-banner.jpg");
  height: 50%;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}

.hero-text {
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
}

.hero-text button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 10px 25px;
  color: black;
  background-color: #ddd;
  text-align: center;
  cursor: pointer;
}

.hero-text button:hover {
  background-color: #555;
  color: white;
}
</style>

<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

.bg-img {
  /* The image used */
  background-image: url("gallary-banner.jpg");

  min-height: 280px;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  
  /* Needed to position the navbar */
  position: relative;
}

/* Position the navbar container inside the image */
.container {
  position: top;
  margin: 20px;
  width: 100%;
}

/* The navbar */
.topnav {
  overflow: hidden;
  background-color:transparent  ;
}

/* Navbar links */
.topnav a {
  float: left;
  color: black;
  text-align: center;
  padding: 12px 14px;
  text-decoration: none;
  font-size: 15px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}
</style>
<style type="text/css">
		table{
			border-collapse: collapse;
			width: 100%;
			color: #000000;
			font-family: monospace;
			font-size: 18px;
			text-align: Left;
		}
		th{
			background-color: #005f69;
			color: white;
		}
</style>
</head>
<body>

<div class="hero-image">
	<div class="bg-img">
		<div class="container">
		
		<div class="topnav">
			<a href="index1.php">Home</a>
			<a href="about1.php">About</a>
			<a href="hotels2.php">Hotels</a>
			<a href="package1.php">Packages</a>
			<a href="gallery.php">Elements</a>
			 <a href="flights.php">Flights</a>
			<a href="registration1.php">Register</a>
		</div>
		</div>
	</div>
  <div class="hero-text">
    <h1 style="font-size:50px">Packages</h1>
    <p>Home->Packages</p>
    
  </div>
</div>

<table>
					<tr>
						<th>Package_Name</th>
						<th>Places</th>
						<th>No_of_Days</th>
						<th>Price_per_Person</th>
					</tr>
				<?php
					$servername = "localhost";
					$username = "root";
					$password = "";
					$dbname = "package";

					// Create connection
					$conn = new mysqli($servername, $username, $password, $dbname);
					// Check connection
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					} 

					$sql = "SELECT * FROM pckg";
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
						// output data of each row
						while($row = $result->fetch_assoc()) {
							echo "<tr><td><br>" . $row["Package_Name"]." </td><td><br>" . $row["Places"]."</td><td><br>" . $row["No_of_Days"]."</td><td><br>" . $row["Price_per_Person"]. "</td></tr>";
						}
						echo "</table>";
					} 
					else 
					{
						echo "0 results";
					}
					$conn->close();
				?>
			</table>
			


</body>
</html>