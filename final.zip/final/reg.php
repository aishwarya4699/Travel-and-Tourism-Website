
Saioni Chatterjee
1:09 PM (5 hours ago)
to me

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
table{
			border-collapse: collapse;
			width: 100%;
			color: #000000;
			font-family: monospace;
			font-size: 18px;
			text-align: Left;
		}
		th{
			background-color: #005f69;
			color: white;
		}
body, html {
    height: 100%;
    margin: 0;
    font-family: Arial, Helvetica, sans-serif;
}

.hero-image {
  background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url("C:/xampp/htdocs/final/img/top-banner.jpg");
  height: 50%;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  position: relative;
}

.hero-text {
  text-align: center;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  color: white;
}

.hero-text button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 10px 25px;
  color: black;
  background-color: #ddd;
  text-align: center;
  cursor: pointer;
}

.hero-text button:hover {
  background-color: #555;
  color: white;
}
</style>

<style>
body {font-family: Arial, Helvetica, sans-serif;}
* {box-sizing: border-box;}

.bg-img {
  /* The image used */
  background-image: url("C:/xampp/htdocs/final/img/top-banner.jpg");

  min-height: 380px;

  /* Center and scale the image nicely */
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;
  
  /* Needed to position the navbar */
  position: relative;
}

/* Position the navbar container inside the image */
.container {
  position: absolute;
  margin: 20px;
  width: auto;
}

/* The navbar */
.topnav {
  overflow: hidden;
  background-color:#add8e6  ;
}

/* Navbar links */
.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}
</style>
</head>
<body>
<div class="hero-image">
	<div class="bg-img">
		<div class="container" >
		<div class="topnav">
		<img src="C:/xampp/htdocs/web_proj/img/logo.png" align="right"  >
			<a href="#home">Home</a>
			<a href="#news">News</a>
			<a href="#contact">Contact</a>
			<a href="#about">About</a>
		</div>
		</div>
	</div>
  <div class="hero-text">
    <h1 style="font-size:50px">About Us</h1>
    <p>Home->Flights</p>
  </div>
</div>
<table>
					<tr>
						<th>Flight_Name</th>
						<th>Places</th>
						<th>Departure</th>
						<th>Arrival</th>
						<th>Price</th>
					</tr>
				<?php
					$servername = "localhost";
					$username = "root";
					$password = "";
					$dbname = "data2";

					// Create connection
					$conn = new mysqli($servername, $username, $password, $dbname);
					// Check connection
					if ($conn->connect_error) {
						die("Connection failed: " . $conn->connect_error);
					} 

					$sql = "SELECT * FROM flight_det";
					$result = $conn->query($sql);

					if ($result->num_rows > 0) {
						// output data of each row
						while($row = $result->fetch_assoc()) {
							echo "<tr><td><br>" . $row["Flight_Name"]." </td><td><br>" . $row["Places"]."</td><td><br>" . $row["Departure"]."</td><td><br>" . $row["Arrival"]. "</td><td><br>" . $row["Price"]. "</td></tr>";
						}
						echo "</table>";
					} 
					else 
					{
						echo "0 results";
					}
					$conn->close();
				?>
			</table>
</body>
</html>